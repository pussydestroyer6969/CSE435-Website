Welcome to the v1 of team SCC2's prototype!

To run the Jar file, please install JRE (java runtime environment) or JDK (java developement kit).

Links: JRE: https://www.oracle.com/technetwork/java/javase/downloads/jre8-downloads-2133155.html
JDK: https://docs.oracle.com/javase/8/docs/technotes/guides/install/windows_jdk_install.html

